<?php
require_once "Controlador/plantilla.controlador.php";
require_once "Controlador/usuario.controlador.php";
require_once "Modelo/usuario.modelo.php";

$plantilla = new PlantillaControlador();
$plantilla -> CargarPlantilla();

