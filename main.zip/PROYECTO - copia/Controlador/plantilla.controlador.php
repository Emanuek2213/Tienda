<?php

class PlantillaControlador{

    public function CargarPlantilla(){
        include "Vista/plantilla.php";
    }
}

?>